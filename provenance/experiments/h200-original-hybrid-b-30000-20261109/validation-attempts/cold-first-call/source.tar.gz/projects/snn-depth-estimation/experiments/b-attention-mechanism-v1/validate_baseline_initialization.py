"""Native-key initialization identity and zero-B-residual native NPU output parity."""
import argparse,hashlib,json,sys
from pathlib import Path
import torch
EXP=Path(__file__).resolve().parent;PROJECT=EXP.parents[1]
sys.path[:0]=[str(PROJECT),str(EXP)]
from settings import load
from npu_backend import configure,environment
from core.spiking_attention_placement import install
p=argparse.ArgumentParser()
for n in ('initialization','data-root','manifest','output'):p.add_argument('--'+n,type=Path,required=True)
a=p.parse_args();torch.set_num_threads(4)
driver_path=PROJECT/'experiments/spiking-transformer-stereo/scripts/run_experiment.py';sys.path.insert(0,str(driver_path.parent));driver=load('baseline_parity_driver',driver_path)
contract=load('baseline_parity_contract',EXP.parent/'spiking-attention-placement-phase2/protocol.py')
initial=torch.load(a.initialization,map_location='cpu',weights_only=False);native={n:v for n,v in initial['model'].items() if not n.startswith('placement.')}
original=driver.build_model('original',1234);hybrid=install(driver.build_model('original',1234),'B')
assert contract.tensor_hash(initial['model'])=='b37335857fd34f9f5aaa1cf203f906304f7edbd965447ff7dad3953172d47bd4'
assert original.state_dict().keys()==native.keys()
assert hybrid.state_dict().keys()==initial['model'].keys()
for n,v in original.state_dict().items():assert torch.equal(v,native[n]) and torch.equal(v,hybrid.state_dict()[n]),n
for n,v in hybrid.state_dict().items():assert torch.equal(v,initial['model'][n]),n
assert torch.count_nonzero(hybrid.placement.output.weight)==torch.count_nonzero(hybrid.placement.output.bias)==0
record=dict(status='checking',native_tensor_count=len(native),native_initial_sha256=contract.tensor_hash(native),hybrid_initial_sha256=contract.tensor_hash(initial['model']),cuda_available=torch.cuda.is_available(),cuda_comparison='not_available_on_assigned_host',tolerance=dict(atol=1e-5,rtol=1e-5))
device=configure(0)
from input_pipeline import NativeBytesDataset
manifest=json.loads(a.manifest.read_text());order=torch.randperm(960,generator=torch.Generator().manual_seed(1234)).tolist()
from input_pipeline_npu import prepare_rank_batch
batch=prepare_rank_batch(NativeBytesDataset(a.data_root,manifest['train']),order,0,1234,0,1,global_batch=8,micro_batch=4)
left,right,_,_=batch['microbatches'][0]['tensors'];left,right=left.to(device).float(),right.to(device).float()
outputs=[]
with torch.no_grad():
 for model in (original,hybrid):
  model=model.to(device).eval();pred=driver.forward(model,left,right,16);assert torch.isfinite(pred).all();outputs.append(pred.cpu());driver.reset_model(model);model.to('cpu');torch.npu.empty_cache()
delta=(outputs[0]-outputs[1]).abs();assert torch.allclose(*outputs,**record['tolerance'])
record.update(status='passed',native_batch_shape=list(left.shape),initial_prediction_max_abs=float(delta.max()),environment=environment(),initialization_file_sha256=hashlib.sha256(a.initialization.read_bytes()).hexdigest())
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
