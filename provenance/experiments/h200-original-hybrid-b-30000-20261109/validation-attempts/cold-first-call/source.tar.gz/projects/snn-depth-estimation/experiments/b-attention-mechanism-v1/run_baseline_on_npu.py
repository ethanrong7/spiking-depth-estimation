"""Launch only the Markdown's fixed single-NPU Original/hybrid pair."""
import argparse,datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
EXP=Path(__file__).resolve().parent
MODELS=('original-non-i','hybrid-b')
def main():
 p=argparse.ArgumentParser()
 p.add_argument('--model',choices=MODELS,required=True)
 p.add_argument('--device',type=int,choices=range(8),required=True)
 for name in ('output-root','data-root','manifest','source-registry','initialization'):p.add_argument('--'+name,type=Path,required=True)
 p.add_argument('--preflight',action='store_true');p.add_argument('--case',default='native')
 p.add_argument('--pause-at',type=int,choices=(2,));p.add_argument('--resume',action='store_true')
 a=p.parse_args();assert a.preflight or a.pause_at is None
 root=a.output_root/'preflight'/a.case/a.model if a.preflight else a.output_root/'seed-1234'/a.model
 identity=json.loads(a.source_registry.read_text())['source_identity_sha256']
 if not a.preflight:
  admission=json.loads((a.output_root/'port-validation.json').read_text());assert admission['status']=='passed' and admission['source_identity']==identity
  cfg=json.loads((a.output_root/'config.json').read_text());assert cfg['models']==list(MODELS) and cfg['updates']==cfg['schedule_total']==30000
  assert cfg['physical_batch']==4 and cfg['accumulation']==2 and cfg['device_count_per_model']==1
 assert (root/'last.pt').exists()==a.resume,'Resume must be explicit and match saved state'
 root.mkdir(parents=True,exist_ok=True)
 stop=3 if a.preflight else 30000
 cmd=[sys.executable,str(EXP/'worker_baseline_npu.py'),'--seed','1234','--model',a.model,'--root',str(root),'--data-root',str(a.data_root),'--manifest',str(a.manifest),'--source-registry',str(a.source_registry),'--initialization',str(a.initialization),'--stop-at',str(stop),'--input-mode','preload','--preload-gib','12','--input-workers','2','--prefetch-depth','2']
 if a.preflight:cmd+=['--preflight']
 if a.pause_at:cmd+=['--pause-at',str(a.pause_at)]
 record=dict(time_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),model=a.model,device=a.device,stop_at=stop,schedule_total=30000,preflight=a.preflight,resume=a.resume,source_identity=identity,command=cmd)
 (root/'launch.json').write_text(json.dumps(record,indent=2)+'\n')
 with (root/'launch-history.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
 env={**os.environ,'ASCEND_RT_VISIBLE_DEVICES':str(a.device),'PYTHONHASHSEED':'1234','HCCL_DETERMINISTIC':'false','OMP_NUM_THREADS':'4','PYTHONDONTWRITEBYTECODE':'1','TMPDIR':'/workspace/cache/tmp','WORLD_SIZE':'1','RANK':'0','LOCAL_RANK':'0'}
 with (root/'stdout.log').open('ab') as out,(root/'stderr.log').open('ab') as err:r=subprocess.run(cmd,env=env,stdout=out,stderr=err)
 if a.pause_at:
  assert r.returncode==75 and json.loads((root/'checkpoint.json').read_text())['update']==a.pause_at
  return 0
 return r.returncode
if __name__=='__main__':raise SystemExit(main())
