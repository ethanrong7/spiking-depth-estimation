"""CPU rank-partition checks; optional real NPU compact-transfer validation."""
import argparse
from pathlib import Path
import sys
import unittest
import torch

HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE.parents[1])]
from input_pipeline_npu import RankPreparedPrefetch
from input_pipeline import prepare_batch
from test_input_pipeline import TinyDataset


class RankInputTests(unittest.TestCase):
    def test_partition_counts_values_and_resume(self):
        torch.set_num_threads(1)
        dataset=TinyDataset()
        order=torch.randperm(len(dataset),generator=torch.Generator().manual_seed(123)).tolist()
        for seed in (1234,2345):
            ranks=[RankPreparedPrefetch(dataset,order,7,10,seed,r,4,workers=2,depth=2) for r in range(4)]
            try:
                for step in range(7,10):
                    whole=prepare_batch(dataset,order,step,seed)
                    parts=[p.get(step) for p in ranks]
                    self.assertEqual(sum(p['valid_count'] for p in parts),whole['valid_count'])
                    self.assertEqual(sum(p['host_batch_bytes'] for p in parts),whole['host_batch_bytes'])
                    for part in parts:
                        self.assertEqual(part['indices'],whole['indices'])
                        self.assertEqual(part['flags'],whole['flags'])
                    for j in range(4):
                        expected=torch.cat([m['tensors'][j] for m in whole['microbatches']])
                        actual=torch.cat([p['microbatches'][0]['tensors'][j] for p in parts])
                        self.assertTrue(torch.equal(actual,expected))
            finally:
                for p in ranks:p.close()

    def test_npu_launcher_forwarding(self):
        from types import SimpleNamespace
        from run_on_npu import command
        a=SimpleNamespace(seed=1234,variant='linear-identity',data_root=Path('/data'),manifest=Path('/manifest'),
            source_registry=Path('/registry'),initialization=Path('/init'),root=Path('/out'),stop_at=5000,
            devices=[0,1,2,3],preflight=False,pause_at=None,input_mode='preload',preload_gib=12.,
            input_workers=2,prefetch_depth=2,resume_transition=Path('/transition.json'),benchmark=False,speed_mode=1,profile_cpu=0,benchmark_physical_batch=None)
        c=command(a)
        for flag,value in [('--input-mode','preload'),('--preload-gib','12.0'),('--input-workers','2'),
                           ('--prefetch-depth','2'),('--resume-transition','/transition.json'),('--stop-at','5000'),('--speed-mode','1'),('--profile-cpu','0')]:
            self.assertEqual(c[c.index(flag)+1],value)


def npu_check():
    import json,os
    from npu_backend import configure
    from input_pipeline import NativeBytesDataset
    from settings import load
    device=configure(0)
    driver_path=HERE.parent/'spiking-transformer-stereo/scripts/run_experiment.py'
    sys.path.insert(0,str(driver_path.parent))
    driver=load('npu_input_native_driver',driver_path)
    root=HERE.parents[3]
    rows=json.loads((root/'configs/synthetic-split.json').read_text())['train']
    data=Path(os.environ['SPIKE_DATA_ROOT'])
    old,new=driver.ManifestDataset(data,rows),NativeBytesDataset(data,rows)
    checked=0
    for index in (0,1,47,119,479,959):
        x,y=old[index],new[index]
        for j in range(4):
            xx=x[j].to(device)
            yy=y[j].to(device)
            if j<2:
                assert y[j].dtype==torch.uint8
                yy=yy.float()
                assert torch.equal(2*xx-1,2*yy-1)
            assert torch.equal(xx,yy),(index,j)
            checked+=1
    print(json.dumps(dict(status='passed',native_samples=6,tensor_comparisons=checked,spike_transfer='uint8_then_FP32',preprocessing='exact')))


if __name__=='__main__':
    if '--npu' in sys.argv:npu_check()
    else:unittest.main()
