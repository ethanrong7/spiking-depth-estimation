"""Disposable CPU/NPU parity checks required by the B-attention handoff."""
import argparse
import copy
import hashlib
import importlib.util
import json
import sys
import traceback
from pathlib import Path
import torch

EXP = Path(__file__).resolve().parent
PROJECT = EXP.parents[1]
sys.path.insert(0, str(PROJECT))
from npu_backend import configure, environment, preserve_rng, rng_state
from core.attention_encoder_controls import VARIANTS, controlled_code, configure_codes
from core.spiking_attention_placement import DescriptorAttention
from core.corr import CorrBlock1D
from core.utils.utils import bilinear_sampler
from core.ALIF import ALIFNode08, ALIFNode16, ALIFNode32


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--data-root', type=Path, required=True)
    args = parser.parse_args()
    device = configure()
    torch.manual_seed(18)
    report = dict(status='running', environment=environment(), checks=[])
    args.output.parent.mkdir(parents=True, exist_ok=True)
    def save():
        temp = args.output.with_suffix('.tmp')
        temp.write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
        temp.replace(args.output)
    def compare(name, actual, expected, atol=1e-4, rtol=2e-3):
        actual, expected = actual.detach().cpu(), expected.detach().cpu()
        delta = (actual-expected).abs()
        item = dict(check=name, max_abs=float(delta.max()),
                    rms=float(delta.square().mean().sqrt()), atol=atol, rtol=rtol,
                    finite=bool(torch.isfinite(actual).all()))
        report['checks'].append(item)
        save()
        torch.testing.assert_close(actual, expected, atol=atol, rtol=rtol)
        item['passed'] = True
    try:
        # Crossed encoder values and local vector-Jacobian products.
        x = torch.linspace(-5.87, 6.03, 263, dtype=torch.float32)
        incoming = torch.randn_like(x)
        for variant, rules in VARIANTS.items():
            pairs = []
            for target in ('cpu', device):
                t=x.to(target).detach().requires_grad_()
                y=controlled_code(t, *rules)
                g,=torch.autograd.grad(y,t,incoming.to(target))
                pairs.append((y,g))
            compare(variant+'/values', pairs[1][0], pairs[0][0], 0, 0)
            compare(variant+'/local_vjp', pairs[1][1], pairs[0][1], 1e-5, 2e-4)
        # Same initial weights and features; open the residual to check Q/K/V.
        base=DescriptorAttention()
        with torch.no_grad(): base.output.weight.normal_(std=.02)
        inputs=[torch.randn(1,256,2,7) for _ in range(2)]
        for variant in VARIANTS:
            records=[]
            for target, checked in [('cpu',False),(device,False),(device,True)]:
                model=copy.deepcopy(base).to(target)
                configure_codes(model.codes,variant)
                values=[x.to(target).detach().requires_grad_() for x in inputs]
                out=model(*values) if checked else model.compute(*values)
                sum(v.square().mean() for v in out).backward()
                records.append(([v.detach().cpu() for v in out],
                                {n:p.grad.detach().cpu() for n,p in model.named_parameters()},
                                [v.grad.detach().cpu() for v in values]))
            for i in (1,2):
                for j in range(2):
                    compare(f'{variant}/attention_{i}_output_{j}',records[i][0][j],records[0][0][j])
                    compare(f'{variant}/attention_{i}_inputgrad_{j}',records[i][2][j],records[0][2][j])
                for n,g in records[i][1].items():
                    compare(f'{variant}/attention_{i}_gradient/{n}',g,records[0][1][n])
                for n in ('q','k','v'): assert records[i][1][f'codes.{n}.weight'].norm()>0
        # Native pixel-coordinate sampling: height-one, fractional, boundary/OOV.
        for height in (1,3):
            data=torch.randn(2,2,height,9)
            coordinates=torch.tensor([[-2.,0.],[-.4,0.],[0.,0.],[.25,0.],[7.8,0.],[8.,0.],[8.7,0.],[10.,0.]])
            coordinates=coordinates.reshape(1,1,-1,2).repeat(2,1,1,1)
            pairs=[]
            for target in ('cpu',device):
                im=data.to(target).detach().requires_grad_()
                xy=coordinates.to(target).detach().requires_grad_()
                result=bilinear_sampler(im,xy)
                result.square().sum().backward()
                pairs.append((result,im.grad,xy.grad))
            for i,label in enumerate(('values','image_gradient','coordinate_gradient')):
                compare(f'grid_sample/H{height}/{label}',pairs[1][i],pairs[0][i])
        left,right=[torch.randn(1,8,2,32) for _ in range(2)]
        coordinates=torch.zeros(1,2,2,32)
        coordinates[:,0]=torch.linspace(-1.3,32.7,32)
        pairs=[]
        for target in ('cpu',device):
            features=[v.to(target).detach().requires_grad_() for v in (left,right)]
            xy=coordinates.to(target).detach().requires_grad_()
            result=CorrBlock1D(*features,num_levels=4,radius=4)(xy)
            result.square().mean().backward()
            pairs.append((result,features[0].grad,features[1].grad,xy.grad))
        for i,label in enumerate(('values','left_gradient','right_gradient','coordinate_gradient')):
            compare('correlation_pyramid/'+label,pairs[1][i],pairs[0][i])
        # ALIF recurrence, transposed convolution, scripted reset and state reset.
        for cls in (ALIFNode32,ALIFNode16,ALIFNode08):
            model=cls()
            arrays=[torch.randn(1,128,2,3),torch.randn(1,128,4,6)]
            if cls is ALIFNode32: arrays[0]=torch.randn(1,128,4,6)
            coeff=[torch.full((1,128,4,6),v) for v in (.6,.8,.7)]
            pairs=[]
            for target in ('cpu',device):
                node=copy.deepcopy(model).to(target)
                values=[v.to(target).detach().requires_grad_() for v in arrays+coeff]
                outputs=[]
                for _ in range(3):
                    out=node(*values)
                    outputs.append(out[0] if isinstance(out,tuple) else out)
                loss=sum(o.sum() for o in outputs)+node.v.sum()
                loss.backward()
                pairs.append((torch.stack(outputs),node.v.detach(),
                              {n:p.grad for n,p in node.named_parameters()},
                              [v.grad for v in values]))
                node.reset()
                assert node.v==0. and node.spike==0.
            for j,label in enumerate(('spikes','voltage')):compare(cls.__name__+'/'+label,pairs[1][j],pairs[0][j])
            for n,g in pairs[0][2].items():compare(cls.__name__+'/parameter/'+n,pairs[1][2][n],g)
            for j,g in enumerate(pairs[0][3]):
                if g is not None:compare(cls.__name__+f'/input/{j}',pairs[1][3][j],g)
        before=rng_state()
        with preserve_rng():
            torch.rand(9);torch.rand(9,device=device)
        after=rng_state()
        assert torch.equal(before['torch'],after['torch']) and torch.equal(before['npu'],after['npu'])
        report['rng_guard_passed']=True
        raw=args.manifest.read_bytes()
        assert hashlib.sha256(raw).hexdigest()=='bad4369b6fd8b0cdf871a20b1727c2d9b59733a16bd33f75904227bdfef4510a'
        manifest=json.loads(raw)
        assert len(manifest['train'])==960 and len(manifest['dev'])==60
        missing=[]
        for row in manifest['train']+manifest['dev']:
            for key in ('spike_l','spike_r','depth'):
                if not (args.data_root/row[key]).is_file():missing.append(row[key])
        assert not missing,missing
        report['dataset_files']=dict(train_frames=960,dev_frames=60,checked_paths=3060,missing=missing,test_access=False)
        torch.npu.synchronize()
        report['peak_allocated_mib']=torch.npu.max_memory_allocated()/2**20
        report['status']='passed'
    except Exception:
        report['status']='failed'
        report['error']=traceback.format_exc()
        raise
    finally:
        save()
    print(json.dumps(dict(status=report['status'],checks=len(report['checks']))))


if __name__=='__main__':main()
