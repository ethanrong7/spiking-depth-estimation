"""Explicit, gated NPU stage launcher. Never launches the full cell catalog."""
import argparse
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
from settings import EXP, VARIANTS, SEEDS, add_input_arguments


def command(args):
    worker=[str(EXP/'worker_npu.py'),'--seed',str(args.seed),'--variant',args.variant,
            '--data-root',str(args.data_root),'--manifest',str(args.manifest),
            '--source-registry',str(args.source_registry),'--initialization',str(args.initialization),
            '--root',str(args.root),'--stop-at',str(args.stop_at)]
    worker+=['--input-mode',args.input_mode,'--preload-gib',str(args.preload_gib),
             '--input-workers',str(args.input_workers),'--prefetch-depth',str(args.prefetch_depth)]
    if args.resume_transition is not None:worker+=['--resume-transition',str(args.resume_transition)]
    worker+=['--speed-mode',str(args.speed_mode),'--profile-cpu',str(args.profile_cpu)]
    if args.benchmark:worker+=['--benchmark']
    if args.benchmark_physical_batch is not None:worker+=['--benchmark-physical-batch',str(args.benchmark_physical_batch)]
    if args.preflight:worker+=['--preflight']
    if args.pause_at is not None:worker+=['--pause-at',str(args.pause_at)]
    return [sys.executable,'-m','torch.distributed.run','--standalone',
            '--nproc-per-node',str(len(args.devices)),*worker]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--seed',type=int,choices=SEEDS,required=True)
    p.add_argument('--variant',choices=VARIANTS,required=True)
    p.add_argument('--devices',type=lambda v:[int(x) for x in v.split(',')],required=True)
    for key in ('output-root','data-root','manifest','source-registry','initialization'):
        p.add_argument('--'+key,type=Path,required=True)
    p.add_argument('--stop-at',type=int,required=True)
    p.add_argument('--preflight',action='store_true')
    p.add_argument('--benchmark',action='store_true')
    p.add_argument('--benchmark-physical-batch',type=int,choices=(2,4,8,16))
    p.add_argument('--speed-mode',type=int,choices=(0,1),default=int(os.environ.get('B_ATTENTION_SPEED_MODE','1')))
    p.add_argument('--profile-cpu',type=int,choices=(0,1),default=int(os.environ.get('B_ATTENTION_PROFILE_CPU','0')))
    p.add_argument('--case',default='native')
    p.add_argument('--pause-at',type=int)
    p.add_argument('--resume',action='store_true')
    p.add_argument('--resume-transition',type=Path)
    add_input_arguments(p)
    a=p.parse_args()
    assert len(a.devices) in (1,4) and len(set(a.devices))==len(a.devices)
    assert set(a.devices)<=set(range(8)), 'User scope: physical NPUs 0-7 only'
    catalog=json.loads((EXP/'configs/matrix-npu.json').read_text())
    assert any(row['seed']==a.seed and row['variant']==a.variant for row in catalog['runs'])
    cell=a.output_root/f'seed-{a.seed}'/a.variant
    assert not (a.preflight and a.benchmark)
    assert a.benchmark or a.benchmark_physical_batch is None
    a.root=cell/'preflight'/a.case if a.preflight else (cell/'benchmark'/a.case if a.benchmark else cell/'train')
    if not a.preflight and not a.benchmark:
        validation=json.loads((a.output_root/'port-validation.json').read_text())
        assert validation['status']=='passed'
        source=json.loads(a.source_registry.read_text())['source_identity_sha256']
        assert validation['source_identity']==source
        decisions=[json.loads(line) for line in (a.output_root/'stage-decisions.jsonl').read_text().splitlines()]
        assert any(d.get('approved_runs') and any(r['seed']==a.seed and r['variant']==a.variant
            and r['stop_at']==a.stop_at and r['devices']==a.devices for r in d['approved_runs']) for d in decisions)
    if a.benchmark:
        assert a.stop_at in (100,200) and not a.resume
        admission=json.loads((a.output_root/'benchmark-admission.json').read_text())
        assert admission['status']=='passed' and admission['source_identity']==json.loads(a.source_registry.read_text())['source_identity_sha256']
    checkpoint=a.root/'B/last.pt'
    assert checkpoint.exists()==a.resume, 'Explicit resume must match checkpoint presence'
    a.root.mkdir(parents=True,exist_ok=True)
    env=os.environ.copy();env.update(ASCEND_RT_VISIBLE_DEVICES=','.join(map(str,a.devices)),
        PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='4',OPENCV_IO_ENABLE_OPENEXR='1',
        HCCL_DETERMINISTIC='false',PYTHONHASHSEED=str(a.seed))
    argv=command(a)
    record=dict(time_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),argv=argv,
                devices=a.devices,seed=a.seed,variant=a.variant,stage_budget=a.stop_at,
                schedule_total=30000,preflight=a.preflight,benchmark=a.benchmark,speed_mode=a.speed_mode,profile_cpu=a.profile_cpu,resume=a.resume,
                source_registry=json.loads(a.source_registry.read_text()))
    (a.root/'launch.json').write_text(json.dumps(record,indent=2)+'\n')
    with (a.root/'launch-history.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
    with (a.root/'stdout.log').open('ab') as out,(a.root/'stderr.log').open('ab') as err:
        result=subprocess.run(argv,env=env,stdout=out,stderr=err)
    if a.pause_at is not None:
        ck=json.loads((a.root/'B/checkpoint.json').read_text())
        assert ck['complete'] and ck['update']==a.pause_at
        assert not (a.root/'B/result.json').exists()
        return 0
    if result.returncode:raise SystemExit(result.returncode)
    state=json.loads((a.root/'B/result.json').read_text())
    assert state['updates']==a.stop_at and state['scheduler_last_epoch']==a.stop_at
    assert state['finite_model_optimizer']
    expected_batch=(a.benchmark_physical_batch*len(a.devices)) if a.benchmark_physical_batch is not None else 8
    assert state['samples_seen']==a.stop_at*expected_batch
    if a.benchmark:
        assert state['status']=='BENCHMARK_COMPLETED' and state['endpoint_kind']=='benchmark'
    if not a.preflight and not a.benchmark:
        assert (a.root/f'B/step-{a.stop_at}.pt').exists() and a.stop_at in state['evaluated']
        assert state['status']==('COMPLETED' if a.stop_at==30000 else 'SCREEN_COMPLETED')
    print(json.dumps(dict(status='verified_endpoint',root=str(a.root),update=a.stop_at)))


if __name__=='__main__':raise SystemExit(main())
