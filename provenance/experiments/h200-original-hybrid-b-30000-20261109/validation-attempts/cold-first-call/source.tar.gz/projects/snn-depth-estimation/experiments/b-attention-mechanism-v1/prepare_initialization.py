"""Save one identical CPU initialization per seed for all four NPU cells."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import torch
from settings import EXP, load

PROJECT=EXP.parents[1]
sys.path.insert(0,str(PROJECT))
from core.attention_encoder_controls import install, VARIANTS


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=False)
    path=PROJECT/'experiments/spiking-transformer-stereo/scripts/run_experiment.py'
    sys.path.insert(0,str(path.parent))
    driver=load('initialization_native_driver',path)
    contract=load('initialization_contract',EXP.parent/'spiking-attention-placement-phase2/protocol.py')
    records=[]
    for seed in (1234,2345):
        states={}
        reference=None
        for variant in VARIANTS:
            model=install(driver.build_model('original',seed),'B',variant=variant,seed=seed)
            digest=contract.tensor_hash(model.state_dict())
            states[variant]=digest
            if reference is None:reference={n:v.detach().clone() for n,v in model.state_dict().items()}
        assert len(set(states.values()))==1
        path=args.output/f'seed-{seed}.pt'
        torch.save(dict(seed=seed,model=reference,tensor_sha256=digest,variants=states),path)
        records.append(dict(seed=seed,variants=states,tensor_sha256=digest,
                file=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    (args.output/'initialization.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(records))


if __name__=='__main__':main()
