"""Native CUDA configuration, metadata and exact RNG checkpoint handling."""
from contextlib import contextmanager
import os,random,sys
import numpy as np
import torch

def configure(index=0):
    torch.set_num_threads(6)
    assert torch.cuda.is_available() and torch.cuda.device_count()==1
    torch.cuda.set_device(index)
    expected=os.environ['EXPECTED_GPU_UUID'].removeprefix('GPU-')
    assert str(torch.cuda.get_device_properties(index).uuid).removeprefix('GPU-')==expected
    torch.use_deterministic_algorithms(False)
    torch.backends.cudnn.deterministic=True
    torch.backends.cudnn.benchmark=False
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=True
    return torch.device('cuda',index)

def environment():
    p=torch.cuda.get_device_properties(0)
    return dict(python=sys.version,torch=torch.__version__,cuda=torch.version.cuda,cudnn=torch.backends.cudnn.version(),gpu_name=p.name,gpu_uuid=str(p.uuid),device_count=torch.cuda.device_count(),visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'),precision=dict(dtype='float32',mixed_precision=False,deterministic_algorithms=torch.are_deterministic_algorithms_enabled(),cudnn_deterministic=torch.backends.cudnn.deterministic,cudnn_benchmark=torch.backends.cudnn.benchmark,conv_allow_tf32=torch.backends.cudnn.allow_tf32,matmul_allow_tf32=torch.backends.cuda.matmul.allow_tf32))

def rng_state(loader=None):
    return dict(python=random.getstate(),numpy=np.random.get_state(),torch=torch.get_rng_state(),cuda=torch.cuda.get_rng_state().cpu(),loader=loader.generator.get_state() if loader is not None else None)

def restore_rng(state,loader=None):
    random.setstate(state['python']);np.random.set_state(state['numpy']);torch.set_rng_state(state['torch']);torch.cuda.set_rng_state(state['cuda'])
    if loader is not None:loader.generator.set_state(state['loader'])

@contextmanager
def preserve_rng():
    state=rng_state()
    try:yield
    finally:restore_rng(state)

def cpu_tree(value):
    if isinstance(value,torch.Tensor):return value.detach().cpu().clone()
    if isinstance(value,dict):return {k:cpu_tree(v) for k,v in value.items()}
    if isinstance(value,list):return [cpu_tree(v) for v in value]
    if isinstance(value,tuple):return tuple(cpu_tree(v) for v in value)
    return value
