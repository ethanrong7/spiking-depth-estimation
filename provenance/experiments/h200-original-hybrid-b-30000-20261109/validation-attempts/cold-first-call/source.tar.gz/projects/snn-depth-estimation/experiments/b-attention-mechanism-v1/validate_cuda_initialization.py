"""Verify historical CPU initialization and native-input zero-B CUDA output parity."""
import argparse,hashlib,json,sys
from pathlib import Path
import torch
EXP=Path(__file__).resolve().parent;PROJECT=EXP.parents[1]
sys.path[:0]=[str(PROJECT),str(EXP)]
from settings import load
from core.spiking_attention_placement import install
p=argparse.ArgumentParser()
for n in ('initialization','data-root','manifest','output'):p.add_argument('--'+n,type=Path,required=True)
p.add_argument('--initialize-only',action='store_true');a=p.parse_args();torch.set_num_threads(6)
driver_path=PROJECT/'experiments/spiking-transformer-stereo/scripts/run_experiment.py';sys.path.insert(0,str(driver_path.parent));driver=load('cuda_parity_driver',driver_path)
contract=load('cuda_parity_contract',EXP.parent/'spiking-attention-placement-phase2/protocol.py')
original=driver.build_model('original',1234);hybrid=install(driver.build_model('original',1234),'B')
full=contract.tensor_hash(hybrid.state_dict());assert full=='b37335857fd34f9f5aaa1cf203f906304f7edbd965447ff7dad3953172d47bd4'
native={n:v for n,v in hybrid.state_dict().items() if not n.startswith('placement.')}
assert original.state_dict().keys()==native.keys()
for n,v in original.state_dict().items():assert torch.equal(v,native[n]),n
native_hash=contract.tensor_hash(native);assert native_hash=='8ceac15b09ce188f9ee52ad5a8eca8e68727cbbb2887a012874d7246dc6495ca'
shared=contract.tensor_hash({n:v for n,v in native.items() if n.startswith(('fnet.','cnet.','context_zqr_convs.'))});assert shared=='2085df6ea20073c3a9804d79f6baee94e8e9bfe41facda47e3f292fd3cc9394d'
a.initialization.parent.mkdir(parents=True,exist_ok=True)
if not a.initialization.exists():torch.save(dict(seed=1234,model=hybrid.state_dict(),tensor_sha256=full),a.initialization)
else:
 initial=torch.load(a.initialization,map_location='cpu',weights_only=False);assert contract.tensor_hash(initial['model'])==full
record=dict(status='initialization_passed',native_tensor_count=len(native),native_initial_sha256=native_hash,hybrid_initial_sha256=full,shared_initial_sha256=shared,initialization_file_sha256=hashlib.sha256(a.initialization.read_bytes()).hexdigest(),tolerance=dict(atol=1e-5,rtol=1e-5))
if not a.initialize_only:
 from runtime_cuda import configure,environment
 from input_pipeline import NativeBytesDataset,prepare_batch
 device=configure(0);manifest=json.loads(a.manifest.read_text());order=torch.randperm(960,generator=torch.Generator().manual_seed(1234)).tolist()
 compact=NativeBytesDataset(a.data_root,manifest['train']);legacy=driver.ManifestDataset(a.data_root,manifest['train'])
 for i in (order[0],order[7]):
  x,y=legacy[i],compact[i]
  for j in range(4):assert torch.equal(x[j],y[j]),(i,j)
 batch=prepare_batch(compact,order,0,1234);left,right,_,_=batch['microbatches'][0]['tensors'];left,right=left.to(device).float(),right.to(device).float();outputs=[]
 with torch.no_grad():
  for model in (original,hybrid):
   model=model.to(device).eval();pred=driver.forward(model,left,right,16);assert torch.isfinite(pred).all();outputs.append(pred.cpu());driver.reset_model(model);model.to('cpu');torch.cuda.empty_cache()
 delta=(outputs[0]-outputs[1]).abs();assert torch.allclose(*outputs,**record['tolerance'])
 record.update(status='passed',native_batch_shape=list(left.shape),initial_prediction_max_abs=float(delta.max()),input_decode_exact=True,environment=environment())
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
